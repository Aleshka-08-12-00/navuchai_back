from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import SQLAlchemyError
from app.dependencies import get_db
from app.crud import get_courses, get_course, create_course, update_course, delete_course, get_current_user, admin_teacher_required
from app.schemas.course import CourseCreate, CourseResponse, CourseWithDetails
from app.schemas.module import ModuleWithLessons
from app.exceptions import NotFoundException, DatabaseException
from app.models import User

router = APIRouter(prefix="/api/courses", tags=["Courses"])

@router.get("/", response_model=list[CourseResponse])
async def list_courses(db: AsyncSession = Depends(get_db)):
    return await get_courses(db)

@router.get("/{course_id}", response_model=CourseWithDetails)
async def retrieve_course(course_id: int, db: AsyncSession = Depends(get_db)):
    return await get_course(db, course_id)

@router.post("/", response_model=CourseResponse, status_code=status.HTTP_201_CREATED, dependencies=[Depends(admin_teacher_required)])
async def create(course: CourseCreate, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    return await create_course(db, course, user.id)

@router.put("/{course_id}", response_model=CourseResponse, dependencies=[Depends(admin_teacher_required)])
async def update(course_id: int, data: CourseCreate, db: AsyncSession = Depends(get_db)):
    return await update_course(db, course_id, data)

@router.delete("/{course_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(admin_teacher_required)])
async def remove(course_id: int, db: AsyncSession = Depends(get_db)):
    await delete_course(db, course_id)

@router.get("/{course_id}/modules", response_model=list[ModuleWithLessons])
async def modules(course_id: int, db: AsyncSession = Depends(get_db)):
    course = await get_course(db, course_id)
    return course.modules
