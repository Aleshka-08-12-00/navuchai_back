from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.models import Lesson
from app.schemas.lesson import LessonCreate
from app.exceptions import NotFoundException

async def create_lesson(db: AsyncSession, data: LessonCreate):
    lesson = Lesson(**data.model_dump())
    db.add(lesson)
    await db.commit()
    await db.refresh(lesson)
    return lesson

async def get_lesson(db: AsyncSession, lesson_id: int):
    result = await db.execute(select(Lesson).where(Lesson.id == lesson_id))
    lesson = result.scalar_one_or_none()
    if not lesson:
        raise NotFoundException("Урок не найден")
    return lesson

async def update_lesson(db: AsyncSession, lesson_id: int, data: LessonCreate):
    lesson = await get_lesson(db, lesson_id)
    lesson.title = data.title
    lesson.content = data.content
    lesson.order = data.order
    await db.commit()
    await db.refresh(lesson)
    return lesson

async def delete_lesson(db: AsyncSession, lesson_id: int):
    lesson = await get_lesson(db, lesson_id)
    await db.delete(lesson)
    await db.commit()
