from typing import Optional, List
from pydantic import BaseModel
from app.schemas.lesson_test import LessonTestBase

class LessonBase(BaseModel):
    id: int
    module_id: int
    title: str
    content: Optional[str] = None
    order: Optional[int] = None
    class Config:
        from_attributes = True

class LessonCreate(BaseModel):
    module_id: int
    title: str
    content: Optional[str] = None
    order: Optional[int] = None

class LessonResponse(LessonBase):
    pass

class LessonWithTests(LessonBase):
    tests: List['LessonTestBase'] = []
    class Config:
        from_attributes = True

LessonWithTests.model_rebuild()