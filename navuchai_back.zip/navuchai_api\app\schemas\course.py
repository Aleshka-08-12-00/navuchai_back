from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel
from app.schemas.module import ModuleBase

class CourseBase(BaseModel):
    id: int
    title: str
    description: Optional[str] = None
    author_id: int
    created_at: datetime
    class Config:
        from_attributes = True

class CourseCreate(BaseModel):
    title: str
    description: Optional[str] = None

class CourseResponse(CourseBase):
    pass

class CourseWithDetails(CourseBase):
    modules: List['ModuleBase'] = []
    class Config:
        from_attributes = True

CourseWithDetails.model_rebuild()
