from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.models import Module
from app.schemas.module import ModuleCreate
from app.exceptions import NotFoundException

async def create_module(db: AsyncSession, data: ModuleCreate):
    module = Module(**data.model_dump())
    db.add(module)
    await db.commit()
    await db.refresh(module)
    return module

async def get_module(db: AsyncSession, module_id: int):
    result = await db.execute(select(Module).where(Module.id == module_id))
    module = result.scalar_one_or_none()
    if not module:
        raise NotFoundException("Модуль не найден")
    return module

async def update_module(db: AsyncSession, module_id: int, data: ModuleCreate):
    module = await get_module(db, module_id)
    module.title = data.title
    module.order = data.order
    await db.commit()
    await db.refresh(module)
    return module

async def delete_module(db: AsyncSession, module_id: int):
    module = await get_module(db, module_id)
    await db.delete(module)
    await db.commit()
