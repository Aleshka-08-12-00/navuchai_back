from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.dependencies import get_db
from app.crud import create_module, get_module, update_module, delete_module, admin_teacher_required
from app.schemas.module import ModuleCreate, ModuleWithLessons
from app.exceptions import NotFoundException
router = APIRouter(prefix="/api/modules", tags=["Modules"], dependencies=[Depends(admin_teacher_required)])

@router.post("/", response_model=ModuleWithLessons, status_code=status.HTTP_201_CREATED)
async def create(data: ModuleCreate, db: AsyncSession = Depends(get_db)):
    return await create_module(db, data)

@router.put("/{module_id}", response_model=ModuleWithLessons)
async def update(module_id: int, data: ModuleCreate, db: AsyncSession = Depends(get_db)):
    return await update_module(db, module_id, data)

@router.delete("/{module_id}", status_code=status.HTTP_204_NO_CONTENT)
async def remove(module_id: int, db: AsyncSession = Depends(get_db)):
    await delete_module(db, module_id)
